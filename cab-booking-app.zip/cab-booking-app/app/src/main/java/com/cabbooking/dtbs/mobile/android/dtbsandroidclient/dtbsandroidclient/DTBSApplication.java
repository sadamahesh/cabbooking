package com.cabbooking.dtbs.mobile.android.dtbsandroidclient.dtbsandroidclient;

import android.app.Application;

/**
 * Bootstraps application and maintains global state.
 *
 * @author MaheshSada
 */
public class DTBSApplication extends Application {
    private static DTBSApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    public static DTBSApplication getInstance() {
        return instance;
    }
}