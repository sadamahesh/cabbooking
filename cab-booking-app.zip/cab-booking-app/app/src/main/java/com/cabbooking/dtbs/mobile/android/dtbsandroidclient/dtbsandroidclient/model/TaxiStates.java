package com.cabbooking.dtbs.mobile.android.dtbsandroidclient.dtbsandroidclient.model;

/**
 * Created by MaheshSada on 28/09/20.
 */
public enum TaxiStates {
    ON_DUTY("ON_DUTY");

    private String description;

    TaxiStates(String description){
        this.description = description;
    }

    public String toString(){
        return this.description;
    }
}
