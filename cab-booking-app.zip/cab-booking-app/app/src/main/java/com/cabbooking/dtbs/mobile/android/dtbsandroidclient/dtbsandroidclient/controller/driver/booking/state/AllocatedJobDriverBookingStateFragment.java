package com.cabbooking.dtbs.mobile.android.dtbsandroidclient.dtbsandroidclient.controller.driver.booking.state;


import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cabbooking.dtbs.mobile.android.dtbsandroidclient.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class AllocatedJobDriverBookingStateFragment extends Fragment {


    public AllocatedJobDriverBookingStateFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_allocated_job_driver_booking_state, container, false);
    }
}
