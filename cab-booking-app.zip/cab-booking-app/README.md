# Find a Ride: Android Client

A cabbooking taxi book system Android client for my interview.

See documentation folder for application design (e.g. UML, wireframes).





